import { PrismaClient } from "@prisma/client"
const prisma = new PrismaClient

export const getMerk = async (req, res) => {
    try {
        const response = await prisma.merk.findMany()
        res.status(200).json(response)
    } catch (error) {
        
    }
}

export const getMerkById = async (req, res) => {
    try {
        const id = req.params.id
        const response = await prisma.merk.findUnique({
            where:{
                id: parseInt(id)
            }
        })
        res.status(200).json(response)


    } catch (error) {
        
    }
}

export const createMerk = async (req, res) => {
    try {
        const {nama_merk} = req.body
        const response = await prisma.merk.create({
            data: {
                nama_merk
            }
        })
        res.status(200).json(response)
    } catch (error) {
        res.status(400).json(message= error.message)
    }
}

export const updateMerk = async (req, res) => {
    try {
        const id = req.params.id
        const {nama_merk} = req.body
        const response = await prisma.merk.update({
            where:{ id: parseInt(id)},
            data:{nama_merk}
        })
        res.status(200).json(response)
    } catch (error) {
        
    }
}

export const deleteMerk = async (req, res) => {
    try {
        const id = req.params.id
        const response = await prisma.merk.delete({
            where:{ id: parseInt(id)}
        })
        res.status(200).json(response)
    } catch (error) {
        
    }
}