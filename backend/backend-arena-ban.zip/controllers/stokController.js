import { PrismaClient } from "@prisma/client"
const prisma = new PrismaClient

export const getStok = async (req, res) => {
    try {
        const response = await prisma.stokHistory.findMany()
        res.status(200).json(response)
    } catch (error) {
        
    }
}

export const getStokById = async (req, res) => {
    try {
        const id = req.params.id
        const response = await prisma.stokHistory.findUnique({
            where:{
                id: parseInt(id)
            }
        })
        res.status(200).json(response)


    } catch (error) {
        
    }
}

export const createStok = async (req, res) => {
  try {
    const { id_barang, jenis, jumlah, keterangan } = req.body;

    const barang = await prisma.barang.findUnique({
      where: { id: parseInt(id_barang) },
      select: { stok: true }
    });

    if (!barang) {
      return res.status(404).json({ message: 'Barang tidak ditemukan' });
    }

    const stok_awal = barang.stok;
    let stok_akhir;

    if (jenis === 'MASUK') {
      stok_akhir = stok_awal + jumlah;
    } else {
      stok_akhir = stok_awal - jumlah;
    }

    // update stok barang
    await prisma.barang.update({
      where: { id: parseInt(id_barang) },
      data: { stok: stok_akhir }
    });

    // catat history stok
    const response = await prisma.stokHistory.create({
      data: {
        id_barang,
        tanggal: new Date(), // otomatis isi tanggal sekarang
        jenis,
        jumlah,
        keterangan,
        stok_setelah: stok_akhir
      }
    });

    res.status(200).json(response);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Terjadi kesalahan saat mencatat stok' });
  }
};



export const updateStok = async (req, res) => {
    try {
        const id = req.params.id
        const {id_barang, jenis, jumlah} = req.body
        const response = await prisma.stokHistory.update({
            where:{ id: parseInt(id)},
            data:{id_barang, jenis, jumlah}
        })
        res.status(200).json(response)
    } catch (error) {
        
    }
}

export const deleteStok = async (req, res) => {
    try {
        const id = req.params.id
        const response = await prisma.stokHistory.delete({
            where:{ id: parseInt(id)}
        })
        res.status(200).json(response)
    } catch (error) {
        
    }
}